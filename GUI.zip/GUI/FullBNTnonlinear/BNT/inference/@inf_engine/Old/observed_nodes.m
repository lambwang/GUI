function onodes = observed_nodes(engine)
% OBSERVED_NODES  Return nodes that are guaranteed to be observed, indep of evidence (generic inf_engine)
% onodes = observed_nodes(engine)

onodes = [];
