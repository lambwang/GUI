function [CPD varargout]= learn_params(CPD, fam, data, ns, cnodes, varargin)
%function CPD = learn_params(CPD, fam, data, ns, cnodes)
% LEARN_PARAMS Compute the maximum likelihood estimate of the params of a gaussian CPD given complete data
% CPD = learn_params(CPD, fam, data, ns, cnodes)
%
% data(i,m) is the value of node i in case m (can be cell array).
% We assume this node has a maximize_params method.

ncases = size(data, 2);
CPD = reset_ess(CPD);
% make a fully observed joint distribution over the family
fmarginal.domain = fam;
fmarginal.T = 1;
fmarginal.mu = [];
fmarginal.Sigma = [];
if ~iscell(data)
  cases = num2cell(data);
else
  cases = data;
end
hidden_bitv = zeros(1, max(fam));

if(length(varargin) == 0)
    for m=1:ncases
      % specify (as a bit vector) which elements in the family domain are hidden
      hidden_bitv = zeros(1, max(fmarginal.domain));
      ev = cases(:,m);
      hidden_bitv(find(isempty(ev)))=1;
      CPD = update_ess(CPD, fmarginal, ev, ns, cnodes, hidden_bitv);
    end
    CPD = maximize_params(CPD);
end;
varargout{1} = 0;
varargout{2} = 0;

%=======================================================================
%nonlinear fit


if length(fam) > 1 && length(varargin) > 0
    input = ones(ncases,1);
    for pc = 1:length(fam)-1
        temp = data(fam(pc),:)';
        Kvar(pc) = var(temp);
        Kcenter(pc) = ffcmw(temp,1);
        while isnan(Kcenter(pc))
            Kcenter(pc) = ffcmw(temp,1);
        end;
        input = [input, exp(-(temp-Kcenter(pc)).^2.*0.5.*inv(Kvar(pc)))];
    end;
    
    [c,b,r] = regress(data(fam(length(fam)),:)',input);
    %S1 = r'*r./(ncases-size(input,2));
    CPD.mean(1,1) = c(1);
    CPD.cov(1,1,1) = var(r,1);
    CPD.weights(1,:,1) = c(2:length(fam))';
    CPD.nparams = 2+length(fam)-1;
    varargout{1} = Kcenter';
    varargout{2} = Kvar';
end;

%Gaussian mixture model for the node without any parents
if length(fam) == 1 && length(varargin) > 0
    
    temp = data(fam(1),:)';
    
    mixModel = gmmb_em(temp,'components',varargin{1});
    
    CPD.mean = mixModel.mu;
    CPD.cov = mixModel.sigma;
    CPD.weights = mixModel.weight;
    CPD.nparams = varargin{1}*3-1;
    
end;









