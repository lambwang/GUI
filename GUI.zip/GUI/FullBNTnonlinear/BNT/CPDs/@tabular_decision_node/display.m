function display(CPD)

disp('tabular decision node object');
disp(struct(CPD)); 
