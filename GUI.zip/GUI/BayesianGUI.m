function varargout = BayesianGUI(varargin)
% BAYESIANGUI M-file for BayesianGUI.fig
%      BAYESIANGUI, by itself, creates a new BAYESIANGUI or raises the existing
%      singleton*.
%
%      H = BAYESIANGUI returns the handle to a new BAYESIANGUI or the handle to
%      the existing singleton*.
%
%      BAYESIANGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BAYESIANGUI.M with the given input arguments.
%
%      BAYESIANGUI('Property','Value',...) creates a new BAYESIANGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before BayesianGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to BayesianGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help BayesianGUI

% Last Modified by GUIDE v2.5 11-Aug-2008 14:23:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BayesianGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @BayesianGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before BayesianGUI is made visible.
function BayesianGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BayesianGUI (see VARARGIN)

% Choose default command line output for BayesianGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes BayesianGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = BayesianGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in OpenF.
function OpenF_Callback(hObject, eventdata, handles)
% hObject    handle to OpenF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global TimeS;
global Ns;
global Nv;
global totalLength;

[filename,pathname] = uigetfile;

disableButtons(handles);
refresh(BayesianGUI);

if (filename == 0 & pathname == 0)
else
    TimeSS = load([pathname, filename]);
    FNs = fieldnames(TimeSS);
    TimeS = getfield(TimeSS,FNs{1});
    [Nv,Ns] = size(TimeS);
    for i=1:Nv
        subplot(Nv,1,i);
        plot(TimeS(i,:));
    end;
    totalLength = size(TimeS,2);
    set(handles.text1,'String',pathname);
    set(handles.dataLength,'String',num2str(Ns));
end;

enableButtons(handles);

% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pathB;
global TimeS;
global Nv;
global Ns;
global totalLength;

Nr = totalLength/Ns;
order = str2num(get(handles.Order,'String'));
nd = (order+1)*Nv;

if (isempty(TimeS)|| Nv == 0 || Ns == 0)
    msgbox('Please Load Data!','Data Error');
    return;
end;

if (Nr-floor(Nr)) ~= 0
    msgbox('data Length setting is incorrect!','setting error');
    return;
end;

for realC = 1:Nr
    for m = 1:order+1
        for n = 1:Nv
            data(n,m,(realC-1)*(Ns-order)+1:realC*(Ns-order)) = TimeS(n,Ns*(realC-1)+order-m+2:Ns*realC-m+1);
        end;
    end;
end;

bData = [];
for m=1:Nv
    for n=order+1:-1:2
        bData = [bData;data(m,n,:)];
    end;
end;

for m=1:Nv
    bData = [bData;data(m,1,:)];
end;

type = repmat({'gaussian'},1,nd);


disableButtons(handles);
set(handles.Result,'String','');

addpath(genpath('./GraphLayout'));

if pathB == 1
    set(handles.dataLength,'Enable','off');
    refresh(BayesianGUI);
    addpath(genpath('./linearBayesianMutiR'));
    dag = learn_struct_K2(bData,ones(1,nd),[1:nd],'discrete',[],'type',type,'params',[],'scoring_fn','bic','ReLength',Ns-order,'Handles',handles);
elseif pathB == 2
    refresh(BayesianGUI);
    addpath(genpath('./FullBNTnonlinear'));
    addpath(genpath('./em'));
    dag = learn_struct_K2(bData,ones(1,nd),[1:nd],'discrete',[],'type',type,'params',[],'scoring_fn','bic','Handles',handles);
end

resultDag = zeros(Nv,Nv);

for i = 1:Nv
    for j= 1:Nv
        if (sum(dag((i-1)*order+1:i*order,j+Nv*order)) > 0)
            resultDag(i,j) = 1;
        end;
    end;
end;

resultStr = {};
rowStr = [];
count = 1;
t = 1;
for i = 1:Nv
    for j=1:Nv
        if i>9
            spacei = '    ';
        else
            spacei = '     ';
        end;
        if j>9
            spacej = '              ';
        else
            spacej =  '               ';
        end;
        space = '                    ';
        s = sprintf('%s%d->%d%s%d',spacei,i,j,spacej,resultDag(i,j));
        if count < 4;
            if count == 1
                rowStr = s;
            else
                rowStr = sprintf('%s%s%s',rowStr,space,s);
            end;
            count =  count+1;
        else
            resultStr{t} = rowStr;
            rowStr = s;
            count = 2;
            t = t + 1;
        end;
    end;
end;

resultStr{t} = rowStr;

set(handles.Result,'String',resultStr);

resultDagt = resultDag;

for i=1:Nv
    resultDagt(i,i) = 0;
end;

figure();
draw_layout(resultDagt);

if pathB == 1
    rmpath(genpath('./linearBayesianMutiR'));
    set(handles.dataLength,'Enable','on');
elseif pathB == 2
    rmpath(genpath('./FullBNTnonlinear'));
    rmpath(genpath('./em'));
end;
rmpath(genpath('./GraphLayout'));

enableButtons(handles);


% --- Executes on selection change in Result.
function Result_Callback(hObject, eventdata, handles)
% hObject    handle to Result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Result contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Result


% --- Executes during object creation, after setting all properties.
function Result_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Order_Callback(hObject, eventdata, handles)
% hObject    handle to Order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order as text
%        str2double(get(hObject,'String')) returns contents of Order as a double
input = str2num(get(hObject,'String'));

if (isempty(input) || input < 1)
     set(hObject,'String','2')
end
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function Order_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function dataLength_Callback(hObject, eventdata, handles)
% hObject    handle to dataLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataLength as text
%        str2double(get(hObject,'String')) returns contents of dataLength as a double
global Ns;
input = str2num(get(hObject,'String'));

if (isempty(input) || input < 1)
     set(hObject,'String','2')
end
Ns = input;
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function dataLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes when selected object is changed in uipanel11.
function uipanel11_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel11 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pathB;
global totalLength;
global Ns;

if hObject == handles.LinearB
    pathB = 1;
    set(handles.dataLength,'Enable','on');
elseif hObject == handles.NonLinearB
    pathB = 2;
    set(handles.dataLength,'Enable','off');
    Ns = totalLength;
    set(handles.dataLength,'String',num2str(Ns));
end;
refresh(BayesianGUI);

function disableButtons(handles)
set(handles.figure1,'Pointer','watch');

set(handles.OpenF,'Enable','off');
set(handles.start,'Enable','off');
set(handles.LinearB,'Enable','off');
set(handles.NonLinearB,'Enable','off');
set(handles.Order,'Enable','off');

function enableButtons(handles)
set(handles.figure1,'Pointer','arrow');

set(handles.OpenF,'Enable','on');
set(handles.start,'Enable','on');
set(handles.LinearB,'Enable','on');
set(handles.NonLinearB,'Enable','on');
set(handles.Order,'Enable','on');
 






















% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

global TimeS;
global Nv;
global Ns;
global totalLength;
global pathB;

TimeS =[];
Nv = 0;
Ns = 0;
totalLength = 0;
pathB = 1;

%axes(handles.timeSeries_axes);


